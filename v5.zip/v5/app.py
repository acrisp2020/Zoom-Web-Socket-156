from flask import Flask, render_template, jsonify, session, request
from flask_socketio import SocketIO, emit, join_room, leave_room, send

app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['SECRET_KEY'] = 'your_secret_key'

# In-memory storage for users and breakout rooms
active_users = []
rooms = []
messages = []

# Initialize SocketIO with gevent
socketio = SocketIO(app, async_mode='gevent')



#----------------Routes----------------------------------------------------------
# Index file route
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/i-chat-room')
def instructor_page():
    return render_template('i-chat-room.html')

@app.route('/s-chat-room')
def student_page():
    return render_template('s-chat-room.html')

# Route to display all users
@app.route('/users')
def display_users():
    return jsonify(active_users)

# Route to display all messages
@app.route('/messages')
def display_messages():
    return jsonify(messages)

@app.route('/breakout-room/<room>')
def breakout_room(room):
    return render_template('breakout-room.html', room=room)

#----------------Routes----------------------------------------------------------


#------------------Websocket Events----------------------------------------------
# WebSocket event for new users
@socketio.on('new_connection')
def handle_new_connection(data):
    username = data.get('username')

    # Ensure unique username
    if any(user['username'] == username for user in active_users):
        emit('username_taken', {'error': 'Username taken'}, room=request.sid)
        return

    # Add user to active users
    active_users.append({'username': username})
    session['username'] = username

    # Notify all users of the new connection
    emit('user_connected', {'username': username}, broadcast=True)
    emit('update_user_list', [user['username'] for user in active_users], broadcast=True)

# WebSocket event for user disconnect
@socketio.on('disconnect')
def handle_disconnect():
    global active_users
    username = session.get('username')
    active_users = [user for user in active_users if user['username'] != username]

    # Notify all users of the updated user list
    emit('update_user_list', [user['username'] for user in active_users], broadcast=True)


# WebSocket event for message broadcasting
@socketio.on('send_message')
def handle_send_message(data):
    message_content = data.get('message')
    username = data.get('username')

    # Save and broadcast the message
    messages.append({'username': username, 'message': message_content})
    emit('receive_message', {'message': message_content, 'username': username}, broadcast=True)

# Create breakout room
@socketio.on('create_BR')
def handle_create_room(data):
    room = data.get('room')

    if room not in rooms:
        rooms.append(room)
        emit('room_created', {'rooms': rooms, 'message': f'Room {room} has been created'}, broadcast=True)
    else:
        emit('error', {'message': f'Room {room} already exists!'}, room=request.sid)

# Join breakout room
@socketio.on('join_BR')
def handle_join_room(data):
    room = data.get('room')
    username = data.get('username')

    if room in rooms:
        join_room(room)
        emit('room_status', {'message': f'{username} has joined {room}'}, room=room)
    else:
        emit('error', {'message': f'Room {room} does not exist!'}, room=request.sid)

# Leave breakout room
@socketio.on('leave_BR')
def handle_leave_room(data):
    room = data.get('room')
    username = data.get('username')
    emit('room_status', {'message': f'{username} has left {room}'}, room=room)
    leave_room(room)  # Leave the specified room  

# Terminate breakout room
@socketio.on('terminate_BR')
def handle_terminate_room(data):
    room = data.get('room')

    if room in rooms:
        rooms.remove(room)
        emit('room_terminated', {'room': room, 'rooms': rooms}, broadcast=True)
    else:
        emit('error', {'message': f'Room {room} does not exist!'}, room=request.sid)


# Request breakout room creation (by students)
@socketio.on('request_create_BR')
def handle_request_create_room(data):
    room = data.get('room')
    username = data.get('username')

    # Notify instructors about the request
    emit('room_request', {'room': room, 'username': username}, broadcast=True)
#------------------Websocket Events----------------------------------------------



# Run the Flask-SocketIO server
if __name__ == '__main__':
    socketio.run(app, host='127.0.0.1', port=5123, debug=True)
