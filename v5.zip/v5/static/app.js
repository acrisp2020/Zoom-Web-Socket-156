const socket = io.connect("127.0.0.1:5123");

// Prompts user for a username once and saves it
let username = prompt("Enter Username:");
if (!username) {
    alert("Username is required to join the application.");
    location.reload(); // Reloads the page if no username is provided
}

// Notifies server of new connection
socket.emit("new_connection", { username: username });

// Function to send messages as Instructor
function sendMessageInstructor() {
    const inputElement = document.getElementById("message-input");
    const message = inputElement.value;

    if (message) {
        socket.emit("send_message", {
            message: message + "(Instructor) ",
            username: username,
        });
        inputElement.value = ""; // Clear the input field
    }
}

// Function to send messages as Student
function sendMessageStudent() {
    const inputElement = document.getElementById("message-input");
    const message = inputElement.value;

    if (message) {
        socket.emit("send_message", { message: message, username: username });
        inputElement.value = ""; // Clear the input field
    }
}

// Create breakout room as Instructor
function createBR(room) {
    socket.emit("create_BR", { room: room });
}

// Function to join Breakout Room
function joinBR(room) {
    socket.emit("join_BR", { room: room, username: username });
}

// Leave breakout room
function leaveBR(room) {
    socket.emit("leave_BR", { room: room, username: username });
}

// Terminate a breakout room
function terminateBR(room) {
    socket.emit("terminate_BR", { room: room });
}

function requestCreateBR(room) {
    socket.emit("request_create_BR", { room: room, username: username });
}

// Update the room list in the DOM
function updateRoomList(rooms) {
    const roomsDiv = document.getElementById("rooms");
    roomsDiv.innerHTML = ""; // Clear the current list

    rooms.forEach((room) => {
        const roomElement = document.createElement("li");
        roomElement.textContent = room;

        // Create "Join" button
        const joinButton = document.createElement("button");
        joinButton.textContent = "Join";
        joinButton.onclick = () => joinBR(room); // Join room with the stored username
        roomElement.appendChild(joinButton);

        const leaveButton = document.createElement("button");
        leaveButton.textContent = "Leave";
        leaveButton.onclick = () => leaveBR(room); // Join room with the stored username
        roomElement.appendChild(leaveButton);

        const terminateButton = document.createElement("button");
        terminateButton.textContent = "Terminate";
        terminateButton.onclick = () => {
            if (confirm(`Are you sure you want to terminate the room "${room}"?`)) {
                terminateBR(room); // Emit terminate event for the room
            }
        };
        roomElement.appendChild(terminateButton);

        // Append the room element to the room list
        roomsDiv.appendChild(roomElement);
    });
}

// Handle 'user_connected' events
socket.on("user_connected", function (data) {
    const chatBox = document.getElementById("chat-box");
    const userElement = document.createElement("p");

    userElement.innerText = `${data.username} has entered the chat.`;
    chatBox.appendChild(userElement);
});

// Listen for messages from the server
socket.on("receive_message", function (data) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("p");

    messageElement.innerText = `${data.username}: ${data.message}`;
    chatBox.appendChild(messageElement);
});

// Handle 'username_taken' event
socket.on("username_taken", function (data) {
    alert(data.error);
    username = prompt("Username Taken, try again");
    socket.emit("new_connection", { username: username });
});

// Handle 'update_user_list'
socket.on("update_user_list", function (users) {
    const userList = document.getElementById("user-list");
    userList.innerHTML = "<h2>Users</h2>"; // Reset the user list

    users.forEach(function (user) {
        const userElement = document.createElement("p");
        userElement.innerText = user; // Display the username
        userList.appendChild(userElement);
    });
});

// Listen for room creation updates
socket.on("room_created", (data) => {
    console.log(data.message); // Example: "Room Room101 has been created"
    updateRoomList(data.rooms); // Update the DOM with the list of rooms
});

// Listen for room status updates (e.g., user joining or leaving)
socket.on("room_status", (data) => {
    console.log(data.message); // Example: "John has joined Room101"
    const statusDiv = document.getElementById("status");
    statusDiv.innerHTML += `<p>${data.message}</p>`;
});

// Listen for termination confirmation
socket.on("room_terminated", (data) => {
    alert(`Room ${data.room} has been terminated.`);
    updateRoomList(data.rooms); // Update the DOM with the updated room list
});

socket.on("leave_BR", (data) => {
    alert(`User ${data.username} has left the room.`);
    updateRoomList(data.rooms); // Update the DOM with the updated room list
});

// Handle error events
socket.on("error", (data) => {
    console.error(data.message); // Example: "Room Room101 already exists!"
    alert(data.message); // Display error to the user
});

// Handle room creation requests from students
socket.on("room_request", (data) => {
    const requestsDiv = document.getElementById("room-requests");

    // Create a new request item
    const requestElement = document.createElement("div");
    requestElement.innerHTML = `<p>Student "${data.username}" requests room "${data.room}"</p>`;

    // Approve Button
    const approveButton = document.createElement("button");
    approveButton.textContent = "Approve";
    approveButton.onclick = () => {
        createBR(data.room); // Create the room as an instructor
        requestElement.remove(); // Remove the request from the list
    };

    // Deny Button
    const denyButton = document.createElement("button");
    denyButton.textContent = "Deny";
    denyButton.onclick = () => {
        requestElement.remove(); // Simply remove the request from the list
    };

    // Append buttons to the request item
    requestElement.appendChild(approveButton);
    requestElement.appendChild(denyButton);

    // Append the request item to the requests list
    requestsDiv.appendChild(requestElement);
});
